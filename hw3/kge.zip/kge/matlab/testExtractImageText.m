% Your code here.
text = extractImageText('../images/01_list.jpg');
text = extractImageText('../images/02_letters.jpg');
text = extractImageText('../images/03_haiku.jpg');
text = extractImageText('../images/04_deep.jpg');