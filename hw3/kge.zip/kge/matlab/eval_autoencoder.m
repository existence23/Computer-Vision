% TODO: load test dataset

% TODO: reshape and adjust the dimensions to be in the order of [height,width,1,sample_index]

% TODO: run predict()
test_recon = predict(..);

